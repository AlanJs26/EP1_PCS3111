#include "Memoria.h"

Memoria::Memoria(){
}

Memoria::~Memoria(){
}