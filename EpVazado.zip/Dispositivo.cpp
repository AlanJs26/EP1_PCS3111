#include "Dispositivo.h"

Dispositivo::Dispositivo(){
}

Dispositivo::~Dispositivo(){
}