#include "Memoria.h"

Memoria::Memoria(){}
Memoria::~Memoria(){}

int Memoria::getTamanho(){
    return tamanho;
}